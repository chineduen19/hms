// Services Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Platform tabs functionality
    const tabButtons = document.querySelectorAll('.tab-btn');
    const pricingTables = document.querySelectorAll('.pricing-table');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons and tables
            tabButtons.forEach(btn => btn.classList.remove('active'));
            pricingTables.forEach(table => table.classList.remove('active'));
            
            // Add active class to clicked button
            button.classList.add('active');
            
            // Show corresponding table
            const platform = button.getAttribute('data-platform');
            const targetTable = document.getElementById(`${platform}-table`);
            if (targetTable) {
                targetTable.classList.add('active');
            }
        });
    });
    
    // Services navigation highlighting
    const serviceNavLinks = document.querySelectorAll('.service-nav-link');
    const serviceSections = document.querySelectorAll('.service-section');
    
    // Function to highlight active service nav link
    function highlightActiveService() {
        const scrollPos = window.scrollY + 200;
        
        serviceSections.forEach((section, index) => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            
            if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
                serviceNavLinks.forEach(link => link.classList.remove('active'));
                if (serviceNavLinks[index]) {
                    serviceNavLinks[index].classList.add('active');
                }
            }
        });
    }
    
    // Smooth scrolling for service navigation
    serviceNavLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                window.scrollTo({
                    top: targetSection.offsetTop - 140,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Listen for scroll events
    window.addEventListener('scroll', highlightActiveService);
    
    // Animation on scroll for package cards
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe package cards
    const packageCards = document.querySelectorAll('.package-card, .growth-package-card');
    packageCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = 'all 0.6s ease';
        observer.observe(card);
    });
    
    // Observe client type cards
    const clientCards = document.querySelectorAll('.client-type');
    clientCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.5s ease';
        observer.observe(card);
    });
    
    // Table row hover effects
    const tableRows = document.querySelectorAll('.pricing-table-content tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', () => {
            row.style.backgroundColor = '#f0f8ff';
        });
        
        row.addEventListener('mouseleave', () => {
            if (!row.classList.contains('featured-row')) {
                row.style.backgroundColor = '';
            }
        });
    });
    
    // Form tracking for analytics (if needed)
    const serviceButtons = document.querySelectorAll('a[href*="forms.gle"], a[href*="docs.google.com/forms"]');
    serviceButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Track form clicks
            console.log('Service form clicked:', button.textContent);
            
            // You can add analytics tracking here
            // gtag('event', 'click', {
            //     'event_category': 'service_request',
            //     'event_label': button.textContent
            // });
        });
    });
    
    // Sticky navigation behavior
    const servicesNav = document.querySelector('.services-overview-detailed');
    let lastScrollTop = 0;
    
    window.addEventListener('scroll', () => {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > lastScrollTop && scrollTop > 100) {
            // Scrolling down
            servicesNav.style.transform = 'translateY(-100%)';
        } else {
            // Scrolling up
            servicesNav.style.transform = 'translateY(0)';
        }
        
        lastScrollTop = scrollTop;
    });
    
    // Price calculator (optional feature)
    function calculateROI(adSpend, conversionRate = 0.02) {
        const estimatedLeads = Math.floor(adSpend * 10 * conversionRate);
        return estimatedLeads;
    }
    
    // Add hover effects to pricing tables
    const pricingCells = document.querySelectorAll('.pricing-table-content td');
    pricingCells.forEach(cell => {
        if (cell.classList.contains('offer')) {
            cell.addEventListener('click', () => {
                // Highlight the offer
                cell.style.animation = 'pulse 0.5s ease-in-out';
                setTimeout(() => {
                    cell.style.animation = '';
                }, 500);
            });
        }
    });
    
    // Initialize highlight on page load
    setTimeout(highlightActiveService, 100);
});

// CSS animation for pulse effect
const style = document.createElement('style');
style.textContent = `
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }
`;
document.head.appendChild(style);