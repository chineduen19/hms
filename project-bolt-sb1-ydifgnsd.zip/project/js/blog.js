// Blog Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Newsletter form handling
    const newsletterForm = document.querySelector('.newsletter-form');
    const newsletterInput = newsletterForm.querySelector('input[type="email"]');
    const newsletterBtn = newsletterForm.querySelector('.btn');
    
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = newsletterInput.value.trim();
        
        if (!email) {
            alert('Please enter your email address.');
            return;
        }
        
        if (!isValidEmail(email)) {
            alert('Please enter a valid email address.');
            return;
        }
        
        // Show loading state
        newsletterBtn.textContent = 'Subscribing...';
        newsletterBtn.disabled = true;
        newsletterForm.classList.add('loading');
        
        // Create email content
        const subject = 'Blog Newsletter Subscription Request';
        const body = `New blog newsletter subscription request:

Email: ${email}
Date: ${new Date().toLocaleString()}
Source: Blog page newsletter signup

Please add this email to the blog newsletter list.

---
This subscription request was submitted through the Hisnak Marketing Services blog page.`;
        
        // Create mailto link
        const mailtoLink = `mailto:enquiries@hms.hisnak.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        
        // Open email client
        window.location.href = mailtoLink;
        
        // Show success message
        setTimeout(() => {
            showSuccessMessage();
            
            // Reset form
            newsletterInput.value = '';
            newsletterBtn.textContent = 'Subscribe';
            newsletterBtn.disabled = false;
            newsletterForm.classList.remove('loading');
            
            // Track subscription (if analytics is set up)
            if (typeof gtag !== 'undefined') {
                gtag('event', 'newsletter_signup', {
                    event_category: 'engagement',
                    event_label: 'blog_newsletter'
                });
            }
        }, 1000);
    });
    
    // Email validation function
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    // Show success message
    function showSuccessMessage() {
        // Create success message if it doesn't exist
        let successMessage = document.querySelector('.success-message');
        if (!successMessage) {
            successMessage = document.createElement('div');
            successMessage.className = 'success-message';
            successMessage.textContent = 'Thank you for subscribing! We\'ll notify you when our blog launches.';
            newsletterForm.parentNode.appendChild(successMessage);
        }
        
        successMessage.classList.add('show');
        
        // Hide success message after 5 seconds
        setTimeout(() => {
            successMessage.classList.remove('show');
        }, 5000);
    }
    
    // Real-time email validation
    newsletterInput.addEventListener('input', function() {
        const email = this.value.trim();
        
        if (email && !isValidEmail(email)) {
            this.style.borderColor = '#e74c3c';
        } else if (email) {
            this.style.borderColor = '#2ecc71';
        } else {
            this.style.borderColor = '#ddd';
        }
    });
    
    // Animation on scroll for content items
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe content items and resource cards
    const animatedElements = document.querySelectorAll('.content-item, .resource-card');
    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'all 0.6s ease';
        observer.observe(element);
    });
    
    // Smooth scrolling for internal links
    const internalLinks = document.querySelectorAll('a[href^="#"]');
    internalLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const offsetTop = targetElement.offsetTop - 100;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Track resource card clicks
    const resourceCards = document.querySelectorAll('.resource-card .btn');
    resourceCards.forEach(btn => {
        btn.addEventListener('click', function() {
            const cardTitle = this.parentNode.querySelector('h3').textContent;
            
            // Track click event
            if (typeof gtag !== 'undefined') {
                gtag('event', 'click', {
                    event_category: 'resource_card',
                    event_label: cardTitle
                });
            }
            
            console.log(`Resource card clicked: ${cardTitle}`);
        });
    });
    
    // Add hover effects to content items
    const contentItems = document.querySelectorAll('.content-item');
    contentItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // Newsletter input focus effects
    newsletterInput.addEventListener('focus', function() {
        this.parentNode.style.transform = 'scale(1.02)';
        this.parentNode.style.transition = 'transform 0.2s ease';
    });
    
    newsletterInput.addEventListener('blur', function() {
        this.parentNode.style.transform = 'scale(1)';
    });
    
    // Keyboard navigation for resource cards
    const resourceCardBtns = document.querySelectorAll('.resource-card .btn');
    resourceCardBtns.forEach((btn, index) => {
        btn.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowRight' && index < resourceCardBtns.length - 1) {
                e.preventDefault();
                resourceCardBtns[index + 1].focus();
            } else if (e.key === 'ArrowLeft' && index > 0) {
                e.preventDefault();
                resourceCardBtns[index - 1].focus();
            }
        });
    });
    
    // Auto-resize newsletter input on mobile
    function adjustInputSize() {
        if (window.innerWidth <= 768) {
            newsletterInput.style.fontSize = '16px'; // Prevents zoom on iOS
        }
    }
    
    adjustInputSize();
    window.addEventListener('resize', adjustInputSize);
    
    // Preload images for better performance
    const imageUrls = [
        'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg',
        'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg'
    ];
    
    imageUrls.forEach(url => {
        const img = new Image();
        img.src = url;
    });
    
    // Add loading states to buttons
    const allButtons = document.querySelectorAll('.btn');
    allButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            if (!this.disabled) {
                this.style.transform = 'scale(0.98)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 150);
            }
        });
    });
    
    // Initialize tooltips for content items (optional)
    contentItems.forEach(item => {
        const title = item.querySelector('h3').textContent;
        item.setAttribute('title', `Learn more about ${title.toLowerCase()}`);
    });
    
    // Performance monitoring
    if ('performance' in window) {
        window.addEventListener('load', function() {
            const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
            console.log(`Blog page loaded in ${loadTime}ms`);
            
            // Track page load time if analytics is available
            if (typeof gtag !== 'undefined') {
                gtag('event', 'timing_complete', {
                    name: 'blog_page_load',
                    value: loadTime
                });
            }
        });
    }
});

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Export functions for potential use in other scripts
window.BlogUtils = {
    isValidEmail: function(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },
    
    trackEvent: function(action, category, label) {
        if (typeof gtag !== 'undefined') {
            gtag('event', action, {
                event_category: category,
                event_label: label
            });
        }
        console.log(`Event tracked: ${action} - ${category} - ${label}`);
    }
};