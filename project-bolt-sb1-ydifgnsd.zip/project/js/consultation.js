// Consultation Form JavaScript

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('consultation-form');
    const submitBtn = document.querySelector('.submit-btn');
    
    // Form validation
    function validateForm() {
        const requiredFields = form.querySelectorAll('input[required], select[required], textarea[required]');
        let isValid = true;
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.style.borderColor = '#e74c3c';
            } else {
                field.style.borderColor = '#2ecc71';
            }
        });
        
        // Validate checkboxes for services
        const serviceCheckboxes = form.querySelectorAll('input[name="services"]:checked');
        if (serviceCheckboxes.length === 0) {
            isValid = false;
            const serviceGroup = form.querySelector('.checkbox-group');
            serviceGroup.style.borderLeft = '4px solid #e74c3c';
        } else {
            const serviceGroup = form.querySelector('.checkbox-group');
            serviceGroup.style.borderLeft = '4px solid #2ecc71';
        }
        
        // Validate email format
        const emailField = form.querySelector('#email');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (emailField.value && !emailRegex.test(emailField.value)) {
            isValid = false;
            emailField.style.borderColor = '#e74c3c';
        }
        
        return isValid;
    }
    
    // Real-time validation on field blur
    const formFields = form.querySelectorAll('input, select, textarea');
    formFields.forEach(field => {
        field.addEventListener('blur', function() {
            if (this.hasAttribute('required') && !this.value.trim()) {
                this.style.borderColor = '#e74c3c';
            } else if (this.value.trim()) {
                this.style.borderColor = '#2ecc71';
            }
        });
        
        field.addEventListener('focus', function() {
            this.style.borderColor = '#2ecc71';
        });
    });
    
    // Handle form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!validateForm()) {
            alert('Please fill in all required fields correctly.');
            return;
        }
        
        // Show loading state
        submitBtn.textContent = 'Submitting...';
        submitBtn.disabled = true;
        form.classList.add('loading');
        
        // Collect form data
        const formData = new FormData(form);
        const data = {};
        
        // Handle regular form fields
        for (let [key, value] of formData.entries()) {
            if (data[key]) {
                // Handle multiple values (like checkboxes)
                if (Array.isArray(data[key])) {
                    data[key].push(value);
                } else {
                    data[key] = [data[key], value];
                }
            } else {
                data[key] = value;
            }
        }
        
        // Handle checkbox groups separately
        const serviceCheckboxes = form.querySelectorAll('input[name="services"]:checked');
        data.services = Array.from(serviceCheckboxes).map(cb => cb.value);
        
        // Format email body
        const emailSubject = `New Consultation Request from ${data.fullName}`;
        const emailBody = formatEmailBody(data);
        
        // Create mailto link
        const mailtoLink = `mailto:enquiries@hms.hisnak.com?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
        
        // Open email client
        window.location.href = mailtoLink;
        
        // Show success message
        setTimeout(() => {
            alert('Thank you for your consultation request! Your email client should have opened with your information. We\'ll respond within 24 hours.');
            
            // Reset form
            form.reset();
            submitBtn.textContent = 'Book My Free Strategy Session';
            submitBtn.disabled = false;
            form.classList.remove('loading');
            
            // Reset field styles
            formFields.forEach(field => {
                field.style.borderColor = '#e0e0e0';
            });
            
            // Track form submission (if analytics is set up)
            if (typeof gtag !== 'undefined') {
                gtag('event', 'form_submit', {
                    event_category: 'consultation',
                    event_label: 'consultation_request'
                });
            }
        }, 1000);
    });
    
    // Format email body function
    function formatEmailBody(data) {
        let body = `CONSULTATION REQUEST\n\n`;
        body += `Contact Information:\n`;
        body += `Name: ${data.fullName}\n`;
        body += `Email: ${data.email}\n`;
        body += `Phone: ${data.phone}\n`;
        body += `Location: ${data.location}\n\n`;
        
        body += `Business Information:\n`;
        body += `Company: ${data.company || 'Not provided'}\n`;
        body += `Industry: ${data.industry}\n`;
        body += `Business Stage: ${data.businessStage}\n`;
        body += `Monthly Revenue: ${data.monthlyRevenue || 'Not disclosed'}\n\n`;
        
        body += `Services of Interest:\n`;
        if (data.services && data.services.length > 0) {
            data.services.forEach(service => {
                body += `- ${service.replace('-', ' ').toUpperCase()}\n`;
            });
        }
        body += `\n`;
        
        body += `Challenges:\n${data.challenges}\n\n`;
        body += `Goals:\n${data.goals}\n\n`;
        
        body += `Project Details:\n`;
        body += `Budget: ${data.budget || 'Not specified'}\n`;
        body += `Timeline: ${data.timeline}\n\n`;
        
        if (data.additionalInfo) {
            body += `Additional Information:\n${data.additionalInfo}\n\n`;
        }
        
        body += `---\nThis consultation request was submitted through the Hisnak Marketing Services website.`;
        
        return body;
    }
    
    // Smooth scrolling for anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const offsetTop = targetElement.offsetTop - 100;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Auto-resize textareas
    const textareas = form.querySelectorAll('textarea');
    textareas.forEach(textarea => {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
    });
    
    // Character count for text areas (optional)
    const challengesField = document.getElementById('challenges');
    const goalsField = document.getElementById('goals');
    
    function addCharacterCount(field, maxLength = 500) {
        const counter = document.createElement('div');
        counter.style.cssText = 'font-size: 0.9rem; color: #666; text-align: right; margin-top: 4px;';
        field.parentNode.appendChild(counter);
        
        function updateCounter() {
            const length = field.value.length;
            counter.textContent = `${length}/${maxLength} characters`;
            
            if (length > maxLength * 0.9) {
                counter.style.color = '#e74c3c';
            } else if (length > maxLength * 0.7) {
                counter.style.color = '#f39c12';
            } else {
                counter.style.color = '#666';
            }
        }
        
        field.addEventListener('input', updateCounter);
        updateCounter();
    }
    
    // Add character counters to text areas
    addCharacterCount(challengesField);
    addCharacterCount(goalsField);
    
    // Form progress indicator (optional)
    function updateProgress() {
        const totalFields = form.querySelectorAll('input[required], select[required], textarea[required]').length;
        const filledFields = Array.from(form.querySelectorAll('input[required], select[required], textarea[required]'))
            .filter(field => field.value.trim() !== '').length;
        
        const progress = Math.round((filledFields / totalFields) * 100);
        
        // You can add a progress bar here if desired
        console.log(`Form completion: ${progress}%`);
    }
    
    // Update progress on field changes
    formFields.forEach(field => {
        if (field.hasAttribute('required')) {
            field.addEventListener('input', updateProgress);
        }
    });
    
    // Initialize progress
    updateProgress();
});

// Additional utility functions
function scrollToElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        const offsetTop = element.offsetTop - 100;
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
}

// Auto-save form data to localStorage (optional)
function saveFormData() {
    const form = document.getElementById('consultation-form');
    const formData = new FormData(form);
    const data = {};
    
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }
    
    localStorage.setItem('consultationFormData', JSON.stringify(data));
}

function loadFormData() {
    const savedData = localStorage.getItem('consultationFormData');
    if (savedData) {
        const data = JSON.parse(savedData);
        const form = document.getElementById('consultation-form');
        
        Object.keys(data).forEach(key => {
            const field = form.querySelector(`[name="${key}"]`);
            if (field && field.type !== 'checkbox') {
                field.value = data[key];
            }
        });
    }
}

// Clear saved data on successful submission
function clearSavedData() {
    localStorage.removeItem('consultationFormData');
}

// Initialize auto-save (commented out by default)
// document.addEventListener('DOMContentLoaded', function() {
//     loadFormData();
//     
//     const form = document.getElementById('consultation-form');
//     form.addEventListener('input', debounce(saveFormData, 1000));
// });

// Debounce function for auto-save
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}